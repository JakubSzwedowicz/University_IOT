package com.example.PiRSpring.repository;

import com.example.PiRSpring.model.Card;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface CardRepository extends JpaRepository<Card, Integer> {
//    @Modifying
//    @Query(value = "INSERT INTO card (RFID_tag, employeeid, card_statusid) values (?1, ?2, ?3)",
//            nativeQuery = true)
//    void saveCard(String RFID_tag, int employeeid, int card_statusid);
}
