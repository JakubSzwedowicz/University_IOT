package com.example.PiRSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PiRSpringWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
